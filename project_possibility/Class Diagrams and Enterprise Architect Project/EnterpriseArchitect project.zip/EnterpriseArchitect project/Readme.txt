Steps to import the XML into Enterprise Architect in order to view class diagrams:

1. Create a new *.eap Enterprise Architect Project.
2. Import the model.xml file by right clicking the root under the Project Browser and selecting "Import from XMI"
3. Give the path to the model.xml file and click Import.
4. The entire tree structure named "MCRCode" gets generated.